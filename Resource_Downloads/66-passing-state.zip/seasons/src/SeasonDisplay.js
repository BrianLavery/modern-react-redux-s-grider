import React from 'react';

const SeasonDisplay = props => {
  console.log(props.lat);

  return <div>Season Display</div>;
};

export default SeasonDisplay;
